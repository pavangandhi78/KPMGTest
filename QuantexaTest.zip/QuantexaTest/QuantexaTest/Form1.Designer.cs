﻿namespace QuantexaTest
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.BtnNoOfFlightsPerMonth = new System.Windows.Forms.Button();
            this.txtFlightFilePath = new System.Windows.Forms.TextBox();
            this.txtPassengerFilePath = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.btnFlightFilePath = new System.Windows.Forms.Button();
            this.btnPassengerFilePath = new System.Windows.Forms.Button();
            this.btnFrequentFlyers = new System.Windows.Forms.Button();
            this.btnFlewMoreThan3Times = new System.Windows.Forms.Button();
            this.btnGreatestNumber = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtCount = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dtpDateTo = new System.Windows.Forms.DateTimePicker();
            this.dtpDateFrom = new System.Windows.Forms.DateTimePicker();
            this.backgroundWorker = new System.ComponentModel.BackgroundWorker();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView
            // 
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Location = new System.Drawing.Point(12, 163);
            this.dataGridView.Name = "dataGridView";
            this.dataGridView.Size = new System.Drawing.Size(684, 340);
            this.dataGridView.TabIndex = 0;
            // 
            // BtnNoOfFlightsPerMonth
            // 
            this.BtnNoOfFlightsPerMonth.Location = new System.Drawing.Point(15, 74);
            this.BtnNoOfFlightsPerMonth.Name = "BtnNoOfFlightsPerMonth";
            this.BtnNoOfFlightsPerMonth.Size = new System.Drawing.Size(111, 37);
            this.BtnNoOfFlightsPerMonth.TabIndex = 1;
            this.BtnNoOfFlightsPerMonth.Text = "No. Of Flights Per Month";
            this.BtnNoOfFlightsPerMonth.UseVisualStyleBackColor = true;
            this.BtnNoOfFlightsPerMonth.Click += new System.EventHandler(this.BtnNoOfFlightsPerMonth_Click);
            // 
            // txtFlightFilePath
            // 
            this.txtFlightFilePath.Location = new System.Drawing.Point(132, 12);
            this.txtFlightFilePath.Name = "txtFlightFilePath";
            this.txtFlightFilePath.Size = new System.Drawing.Size(646, 20);
            this.txtFlightFilePath.TabIndex = 2;
            // 
            // txtPassengerFilePath
            // 
            this.txtPassengerFilePath.Location = new System.Drawing.Point(132, 38);
            this.txtPassengerFilePath.Name = "txtPassengerFilePath";
            this.txtPassengerFilePath.Size = new System.Drawing.Size(646, 20);
            this.txtPassengerFilePath.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Flight Details File Path :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(114, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Passengerls File Path :";
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "Select .csv file";
            this.openFileDialog.Filter = "CSV files (*.csv)|*.csv";
            this.openFileDialog.InitialDirectory = "D:\\Downloads\\Flight_Data";
            this.openFileDialog.Title = "Select a .CSV file";
            // 
            // btnFlightFilePath
            // 
            this.btnFlightFilePath.Location = new System.Drawing.Point(784, 12);
            this.btnFlightFilePath.Name = "btnFlightFilePath";
            this.btnFlightFilePath.Size = new System.Drawing.Size(21, 20);
            this.btnFlightFilePath.TabIndex = 6;
            this.btnFlightFilePath.Text = "...";
            this.btnFlightFilePath.UseVisualStyleBackColor = true;
            this.btnFlightFilePath.Click += new System.EventHandler(this.btnFlightFilePath_Click);
            // 
            // btnPassengerFilePath
            // 
            this.btnPassengerFilePath.Location = new System.Drawing.Point(784, 38);
            this.btnPassengerFilePath.Name = "btnPassengerFilePath";
            this.btnPassengerFilePath.Size = new System.Drawing.Size(21, 20);
            this.btnPassengerFilePath.TabIndex = 7;
            this.btnPassengerFilePath.Text = "...";
            this.btnPassengerFilePath.UseVisualStyleBackColor = true;
            this.btnPassengerFilePath.Click += new System.EventHandler(this.btnPassengerFilePath_Click);
            // 
            // btnFrequentFlyers
            // 
            this.btnFrequentFlyers.Location = new System.Drawing.Point(160, 74);
            this.btnFrequentFlyers.Name = "btnFrequentFlyers";
            this.btnFrequentFlyers.Size = new System.Drawing.Size(111, 37);
            this.btnFrequentFlyers.TabIndex = 8;
            this.btnFrequentFlyers.Text = "100 Most Frequent Flyers";
            this.btnFrequentFlyers.UseVisualStyleBackColor = true;
            this.btnFrequentFlyers.Click += new System.EventHandler(this.btnFrequentFlyers_Click);
            // 
            // btnFlewMoreThan3Times
            // 
            this.btnFlewMoreThan3Times.Location = new System.Drawing.Point(231, 48);
            this.btnFlewMoreThan3Times.Name = "btnFlewMoreThan3Times";
            this.btnFlewMoreThan3Times.Size = new System.Drawing.Size(111, 37);
            this.btnFlewMoreThan3Times.TabIndex = 9;
            this.btnFlewMoreThan3Times.Text = "Flew together more than 3 times";
            this.btnFlewMoreThan3Times.UseVisualStyleBackColor = true;
            this.btnFlewMoreThan3Times.Click += new System.EventHandler(this.btnFlewMoreThan3Times_Click);
            // 
            // btnGreatestNumber
            // 
            this.btnGreatestNumber.Location = new System.Drawing.Point(297, 74);
            this.btnGreatestNumber.Name = "btnGreatestNumber";
            this.btnGreatestNumber.Size = new System.Drawing.Size(153, 37);
            this.btnGreatestNumber.TabIndex = 10;
            this.btnGreatestNumber.Text = "Greatest number of Countries Passenger been";
            this.btnGreatestNumber.UseVisualStyleBackColor = true;
            this.btnGreatestNumber.Click += new System.EventHandler(this.btnGreatestNumber_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtCount);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.dtpDateTo);
            this.groupBox1.Controls.Add(this.dtpDateFrom);
            this.groupBox1.Controls.Add(this.btnFlewMoreThan3Times);
            this.groupBox1.Location = new System.Drawing.Point(488, 66);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(348, 91);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // txtCount
            // 
            this.txtCount.Location = new System.Drawing.Point(260, 16);
            this.txtCount.Name = "txtCount";
            this.txtCount.Size = new System.Drawing.Size(29, 20);
            this.txtCount.TabIndex = 15;
            this.txtCount.Text = "3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(205, 20);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 14;
            this.label5.Text = "Count :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 60);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 13;
            this.label4.Text = "Date To :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Date From :";
            // 
            // dtpDateTo
            // 
            this.dtpDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateTo.Location = new System.Drawing.Point(74, 54);
            this.dtpDateTo.Name = "dtpDateTo";
            this.dtpDateTo.Size = new System.Drawing.Size(115, 20);
            this.dtpDateTo.TabIndex = 11;
            // 
            // dtpDateFrom
            // 
            this.dtpDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDateFrom.Location = new System.Drawing.Point(74, 19);
            this.dtpDateFrom.Name = "dtpDateFrom";
            this.dtpDateFrom.Size = new System.Drawing.Size(115, 20);
            this.dtpDateFrom.TabIndex = 10;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(848, 505);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnGreatestNumber);
            this.Controls.Add(this.btnFrequentFlyers);
            this.Controls.Add(this.btnPassengerFilePath);
            this.Controls.Add(this.btnFlightFilePath);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtPassengerFilePath);
            this.Controls.Add(this.txtFlightFilePath);
            this.Controls.Add(this.BtnNoOfFlightsPerMonth);
            this.Controls.Add(this.dataGridView);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.Button BtnNoOfFlightsPerMonth;
        private System.Windows.Forms.TextBox txtFlightFilePath;
        private System.Windows.Forms.TextBox txtPassengerFilePath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Button btnFlightFilePath;
        private System.Windows.Forms.Button btnPassengerFilePath;
        private System.Windows.Forms.Button btnFrequentFlyers;
        private System.Windows.Forms.Button btnFlewMoreThan3Times;
        private System.Windows.Forms.Button btnGreatestNumber;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtpDateTo;
        private System.Windows.Forms.DateTimePicker dtpDateFrom;
        private System.Windows.Forms.TextBox txtCount;
        private System.ComponentModel.BackgroundWorker backgroundWorker;
    }
}

