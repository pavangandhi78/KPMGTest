﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security;
using System.Windows.Forms;

namespace QuantexaTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dtpDateFrom.Value = new DateTime(2017, 01, 01);
            dtpDateTo.Value = new DateTime(2017, 05, 31);
        }

        private void btnFlightFilePath_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    txtFlightFilePath.Text = openFileDialog.FileName;
                    if (txtFlightFilePath.Text.Trim().Length != 0)
                    {
                        bool isValid = Helper.ValidateFileExtension(txtFlightFilePath.Text);
                        if (!isValid)
                            MessageBox.Show("Invalid file extension. Please select file with .csv extension");
                        else
                        {

                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select a file for Flight data.");
                    }
                    
                }
                catch (SecurityException ex)
                {
                    MessageBox.Show($"Security error.\n\nError message: {ex.Message}\n\n" + $"Details:\n\n{ex.StackTrace}");
                }
            }
            else
            {
                MessageBox.Show("Please select a file for Flight data");
            }
        }

        private void btnPassengerFilePath_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    txtPassengerFilePath.Text = openFileDialog.FileName;
                    if (txtPassengerFilePath.Text.Trim().Length != 0)
                    {
                        bool isValid = Helper.ValidateFileExtension(txtPassengerFilePath.Text);
                        if (!isValid)
                            MessageBox.Show("Invalid file extension. Please select file with .csv extension");
                        else
                        {

                        }
                    }
                    else
                    {
                        MessageBox.Show("Please select file for Passenger data.");
                    }

                }
                catch (SecurityException ex)
                {
                    MessageBox.Show($"Security error.\n\nError message: {ex.Message}\n\n" + $"Details:\n\n{ex.StackTrace}");
                }
            }
            else
            {
                MessageBox.Show("Please select a file for Passenger data.");
            }
        }

        private void BtnNoOfFlightsPerMonth_Click(object sender, EventArgs e)
        {
            if (txtFlightFilePath.Text.Trim().Length != 0)
            {
                DataTable dt = BLFunctions.NoOfFlightsPerMonth(txtFlightFilePath.Text);

                if (dt.Rows.Count > 0)
                    dataGridView.DataSource = dt;
                else
                    dataGridView.DataSource = null;

                dataGridView.Refresh();

            }
            else
            {
                MessageBox.Show("Please provide path to a file for Flight data.");
            }
        }

        private void btnFrequentFlyers_Click(object sender, EventArgs e)
        {

            if (txtFlightFilePath.Text.Trim().Length != 0 && txtPassengerFilePath.Text.Trim().Length != 0)
            {
                DataTable dt = BLFunctions.FrequentFlyers(txtFlightFilePath.Text,txtPassengerFilePath.Text);

                if (dt.Rows.Count > 0)
                    dataGridView.DataSource = dt;
                else
                    dataGridView.DataSource = null;

                dataGridView.Refresh();
               
            }
            else
            {
                if (txtFlightFilePath.Text.Trim().Length == 0 )
                    MessageBox.Show("Please select file for flight data.");
                else if (txtPassengerFilePath.Text.Trim().Length == 0)
                    MessageBox.Show("Please select file for passenger data.");
            }
        }
       
        private void btnGreatestNumber_Click(object sender, EventArgs e)
        {
            if (txtFlightFilePath.Text.Trim().Length != 0)
            {
                ProcessFile pf = new ProcessFile();

                DataTable dt = BLFunctions.GreatestNumberOfFlights(txtFlightFilePath.Text);
                if (dt.Rows.Count > 0)
                    dataGridView.DataSource = dt;
                else
                    dataGridView.DataSource = null;

                dataGridView.Refresh();
            }
            else
            {
                MessageBox.Show("Please provide path to a file for Flight data.");
            }
        }
        
        private void btnFlewMoreThan3Times_Click(object sender, EventArgs e)
        {
            if (txtFlightFilePath.Text.Trim().Length != 0 & Int32.Parse(txtCount.Text) > 0)
            {
                DateTime dt1 = new DateTime(dtpDateFrom.Value.Year, dtpDateFrom.Value.Month, dtpDateFrom.Value.Day);
                DateTime dt2 = new DateTime(dtpDateTo.Value.Year, dtpDateTo.Value.Month, dtpDateTo.Value.Day);

                DataTable dt = BLFunctions.FlownTogether(txtFlightFilePath.Text, Int32.Parse(txtCount.Text), dt1, dt2);

                if (dt.Rows.Count > 0)
                {
                    dataGridView.DataSource = dt;
                    dataGridView.Refresh();
                }
            }
            else
            {
                if (txtFlightFilePath.Text.Trim().Length == 0)
                    MessageBox.Show("Please select file for flight data.");
                if (txtCount.Text.Trim().Length == 0)
                    MessageBox.Show("Please provide no. of flights to get Passenger who flew together.");
            }
        }

    }
}
