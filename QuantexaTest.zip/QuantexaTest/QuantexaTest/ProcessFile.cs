﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.IO;

namespace QuantexaTest
{
    public class ProcessFile
    {
        public ProcessFile()
        { }

        public List<FlightDetails> ReadFlightDetails(string filePath)
        {
            List<FlightDetails> flightDetails = new List<FlightDetails>();

            try
            {
                using (FileStream fs = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (BufferedStream bs = new BufferedStream(fs))
                using (StreamReader sr = new StreamReader(bs))
                {
                    string headerLine = sr.ReadLine();
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] details = line.Split(',');
                        if (details.Length > 0)
                        {
                            flightDetails.Add(GenerateFlightDetails(details));
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
           
            return flightDetails;
        }

        public FlightDetails GenerateFlightDetails(string[] details)
        {
            FlightDetails flDetails = new FlightDetails();

            flDetails.PassengerId = Int32.Parse(details[0]);

            if (details.Length > 1)
                flDetails.FlightId = Int32.Parse(details[1]);
            if (details.Length > 2)
                flDetails.FlightFrom = details[2];
            if (details.Length > 3)
                flDetails.FlightTo = details[3];

            DateTime dt;
            DateTime.TryParse(details[4], out dt);

            flDetails.FlightDate = dt;

            return flDetails;
        }

        public List<PassengerDetails> ReadPassengerDetails(string filePath)
        {
            List<PassengerDetails> passengerDetails = new List<PassengerDetails>();

            try
            {
                using (FileStream fs = File.Open(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (BufferedStream bs = new BufferedStream(fs))
                using (StreamReader sr = new StreamReader(bs))
                {
                    string headerLine = sr.ReadLine();
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] details = line.Split(',');
                        if (details.Length > 0)
                        {
                            passengerDetails.Add(GeneratePassengerDetails(details));
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            
            return passengerDetails;
        }

        public PassengerDetails GeneratePassengerDetails(string[] details)
        {
            PassengerDetails psDetails = new PassengerDetails();

            psDetails.PassengerId = Int32.Parse(details[0]);

            if (details.Length > 1)
                psDetails.FirstName = details[1];
            if (details.Length > 2)
                psDetails.LastName = details[2];
        
            return psDetails;
        }
    }
}
