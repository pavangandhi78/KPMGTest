﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuantexaTest
{
    public static class BLFunctions
    { 
        //Calling Functions

        /// <summary>
        /// Get total number of flights per month
        /// </summary>
        /// <returns></returns>
        public static DataTable NoOfFlightsPerMonth(string FlightDataFilePath)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add(new DataColumn("Month", typeof(Int16)));
            dt.Columns.Add(new DataColumn("Number of Flights", typeof(Int32)));

            ProcessFile pf = new ProcessFile();
            List<FlightDetails> flights = pf.ReadFlightDetails(FlightDataFilePath);

            if (flights.Count > 0)
            {
                var flightsPerMonth = from f in flights
                                      group f by f.FlightDate.Month
                                      into g
                                      select new
                                      {
                                          mth = g.Key,
                                          cnt = g.Count()
                                      };

                foreach (var flight in flightsPerMonth)
                {
                    DataRow row = dt.NewRow();
                    row[0] = flight.mth;
                    row[1] = flight.cnt;
                    dt.Rows.Add(row);
                }
            }
            return dt;
        }

        /// <summary>
        /// Get list of top 100 Frequent flyers
        /// </summary>
        /// <returns></returns>
        public static DataTable FrequentFlyers(string FlightDataFilePath, string PassengerDataFilePath)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add(new DataColumn("PassengerID", typeof(Int16)));
            dt.Columns.Add(new DataColumn("Number of Flights", typeof(Int32)));
            dt.Columns.Add(new DataColumn("First name", typeof(string)));
            dt.Columns.Add(new DataColumn("Last name", typeof(string)));

            ProcessFile pf = new ProcessFile();

            List<FlightDetails> flights = pf.ReadFlightDetails(FlightDataFilePath);

            if (flights.Count > 0)
            {
                List<PassengerDetails> passengers = pf.ReadPassengerDetails(PassengerDataFilePath);
                if (passengers.Count > 0)
                {
                    var frequentFlyers = (from f in flights
                                          join p in passengers on f.PassengerId equals p.PassengerId
                                          group new { f, p } by new { p.PassengerId, p.FirstName, p.LastName }
                                        into g
                                          select new
                                          {
                                              pID = g.Key,
                                              cnt = g.Count(),
                                          }).OrderByDescending(x => x.cnt)
                                          .Take(100).ToList();

                    foreach (var psg in frequentFlyers)
                    {
                        DataRow row = dt.NewRow();
                        row[0] = psg.pID.PassengerId;
                        row[1] = psg.cnt;
                        row[2] = psg.pID.FirstName;
                        row[3] = psg.pID.LastName;

                        dt.Rows.Add(row);
                    }
                }
            }
            return dt;
        }

        /// <summary>
        /// Get List of Passengers who has greatest number of flights before back to UK
        /// </summary>
        /// <returns></returns>
        public static DataTable GreatestNumberOfFlights(string FlightDataFilePath)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add(new DataColumn("Passenger ID", typeof(Int32)));
            dt.Columns.Add(new DataColumn("Longest Run", typeof(Int32)));


            ProcessFile pf = new ProcessFile();
            List<FlightDetails> flights = pf.ReadFlightDetails(FlightDataFilePath);

            if (flights.Count > 0)
            {
                var distinctPassengers = (from f in flights
                                          where f.FlightTo.ToLower() == "uk"
                                          select new
                                          {
                                              f.PassengerId
                                          }).Distinct().OrderBy(x => x.PassengerId).Take(100);

                foreach (var p in distinctPassengers)
                {
                    var LongestRun = (from fd in flights
                                      where fd.PassengerId == p.PassengerId && fd.FlightFrom.ToLower() != "uk" && fd.FlightDate < (from fds in flights where fds.FlightTo.ToLower() == "uk" && fds.PassengerId == fd.PassengerId select fds.FlightDate).Min()
                                      group fd by fd.PassengerId
                                      into g
                                      select new
                                      {
                                          pID = g.Key,
                                          cnt = g.Count(),
                                      }).OrderByDescending(x => x.cnt).ToList();

                    foreach (var psg in LongestRun)
                    {
                        DataRow row = dt.NewRow();
                        row[0] = psg.pID;
                        row[1] = psg.cnt;
                        dt.Rows.Add(row);
                    }
                }
            }

            return dt;
        }

        /// <summary>
        /// Get list of Passengers who flew together based on no. of times and date range
        /// </summary>
        /// <param name="NoOfTimes">No. of times passengers flown together</param>
        /// <param name="From">Flight Date From</param>
        /// <param name="To">Flight Date To</param>
        /// <returns></returns>
        public static DataTable FlownTogether(string FlightDataFilePath, int NoOfTimes, DateTime From, DateTime To)
        {
            DataTable dt = new DataTable();

            ProcessFile pf = new ProcessFile();

            List<FlightDetails> flights = pf.ReadFlightDetails(FlightDataFilePath);

            if (flights.Count > 0)
            {
                dt.Columns.Add(new DataColumn("Passenger 1 ID", typeof(Int32)));
                dt.Columns.Add(new DataColumn("Passenger 2 ID", typeof(Int32)));
                dt.Columns.Add(new DataColumn("Number of Flights together", typeof(Int32)));

                var distinctPassengers = (from f in flights
                                          where (f.FlightDate >= From && f.FlightDate <= To)
                                          group f by f.PassengerId
                                          into g
                                          select new
                                          {
                                              pid = g.Key,
                                              cnt = g.Count()
                                          }).Where(x => x.cnt > NoOfTimes).OrderBy(x => x.pid).Take(100).ToList();

                foreach (var passenger in distinctPassengers)
                {
                    var comparedList = (from f in flights
                                        join fd in flights on f.FlightId equals fd.FlightId
                                        where f.PassengerId == passenger.pid && (f.FlightDate >= From && f.FlightDate <= To)
                                        select new
                                        {
                                            Passenger1Id = f.PassengerId,
                                            Passenger2Id = fd.PassengerId,
                                            FlightId = f.FlightId,
                                            Flight_Date = f.FlightDate
                                        }).Where(x => x.Passenger2Id != passenger.pid).OrderBy(x => x.Passenger2Id).ToList();

                    if (comparedList.Count > 0)
                    {
                        var FlyToGether = (from t in comparedList
                                           group t by t.Passenger2Id
                                           into g
                                           select new
                                           {
                                               p2Id = g.Key,
                                               cnt = g.Count()
                                           }).Where(x => x.cnt > NoOfTimes).OrderByDescending(x => x.cnt).ToList();

                        if (FlyToGether.Count > 0)
                        {
                            foreach (var fly in FlyToGether)
                            {
                                DataRow row = dt.NewRow();
                                row[0] = passenger.pid;
                                row[1] = fly.p2Id;
                                row[2] = fly.cnt;

                                dt.Rows.Add(row);
                            }
                        }
                    }
                }
            }

            return dt;
        }
    }
}
