﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuantexaTest
{
    public class ExtraClass
    {
        //private void btnFlewMoreThan3Times_Click(object sender, EventArgs e)
        //{
        //    if (txtFlightFilePath.Text.Trim().Length != 0 & Int32.Parse(txtCount.Text) > 0 )
        //    {
        //        ProcessFile pf = new ProcessFile();

        //        List<FlightDetails> flights = pf.ReadFlightDetails(txtFlightFilePath.Text);
        //        if (flights.Count > 0)
        //        {
        //            dataGridView.DataSource = null;
        //            dataGridView.Refresh();

        //            //var orderedPsgs = (from f in flights
        //            //                    join p in psgs on f.PassengerId equals p.pID
        //            //                    select new { f.PassengerId, f.FlightId }
        //            //                    ).OrderBy(x => x.PassengerId).ToList();

        //            //List<Test> testList = new List<Test>();

        //            //for (int i = 0; i < orderedPsgs.Count; i++)
        //            //{
        //            //    for (int j = i+1; j < orderedPsgs.Count; j++)
        //            //    {
        //            //        if (orderedPsgs[i] .FlightId == orderedPsgs[j].FlightId)
        //            //        {

        //            //            Test t = new Test();
        //            //            t.Passenger1Id = orderedPsgs[i].PassengerId;
        //            //            t.Passenger2Id = orderedPsgs[j].PassengerId;
        //            //            testList.Add(t);
        //            //        }
        //            //    }
        //            //}

        //            //var Passengers = (from f1 in flights
        //            //                  join f2 in flights on f1.FlightId equals f2.FlightId
        //            //                  group new { f1, f2 } by new { Passenger1Id = f1.PassengerId, Passenger2Id = f2.PassengerId }
        //            //                  into g
        //            //                  select new
        //            //                  {
        //            //                      k = g.Key,
        //            //                      cnt = g.Count(),
        //            //                  }).Where(x => x.cnt > 5).Where(x => x.k.Passenger1Id != x.k.Passenger2Id).ToList();

        //            DateTime dt1 = new DateTime(dtpDateFrom.Value.Year, dtpDateFrom.Value.Month, dtpDateFrom.Value.Day); //new DateTime(2017, 01, 28);
        //            DateTime dt2 = new DateTime(dtpDateTo.Value.Year, dtpDateTo.Value.Month, dtpDateTo.Value.Day); // new DateTime(2017, 04, 07);

        //            var distinctPassengers = (from f in flights
        //                                          //where (f.FlightDate >= dt1 && f.FlightDate <= dt2)
        //                                      where f.PassengerId == 53
        //                                      group f by f.PassengerId
        //                                      into g
        //                                      select new
        //                                      {
        //                                          pid = g.Key,
        //                                          cnt = g.Count()
        //                                      }).Where(x => x.cnt > Int32.Parse(txtCount.Text)).OrderBy(x => x.pid).Take(100).ToList();

        //            var distinctPassengers1 =flights.Select(x => x.PassengerId).Distinct();

        //            DataTable dt = new DataTable();
        //            dt.Columns.Add(new DataColumn("Passenger 1 ID", typeof(Int32)));
        //            dt.Columns.Add(new DataColumn("Passenger 2 ID", typeof(Int32)));
        //            dt.Columns.Add(new DataColumn("Number of Flights together", typeof(Int32)));
        //            int count = 0;

        //            foreach (var passenger in distinctPassengers)
        //            {
        //                //    string query = "select " + passenger + " as Passenger1Id, fds.PassengerId as Passenger2Id,count(*) as NoOfFlightsToGether"
        //                //                   + " from flight_details fds"
        //                //                   + " where fds.PassengerId in"
        //                //                   + " (select fd.passengerId from flight_details f"
        //                //                   + " join flight_details fd on f.FlightId = fd.FlightId"
        //                //                   + " where f.PassengerId = " + passenger + ")"
        //                //                   + " and fds.flightId in (select flightid from flight_details where passengerId = " + passenger + ")"
        //                //                   + " group by fds.PassengerId"
        //                //                   + " having count(*) > 3 and fds.PassengerId <> " + passenger
        //                //                   + " order by NoOfFlightsToGether desc ";
        //                //}

        //                var comparedList = (from f in flights
        //                                    join fd in flights on f.FlightId equals fd.FlightId
        //                                    where f.PassengerId == passenger.pid && (f.FlightDate >= dt1 && f.FlightDate <= dt2)
        //                                    select new
        //                                    {
        //                                        Passenger1Id = f.PassengerId,
        //                                        Passenger2Id = fd.PassengerId,
        //                                        FlightId = f.FlightId,
        //                                        Flight_Date = f.FlightDate
        //                                    }).Where(x => x.Passenger2Id != passenger.pid).OrderBy(x => x.Passenger2Id).ToList();

        //                var FlyToGether = (from t in comparedList
        //                                   group t by t.Passenger2Id
        //                                   into g
        //                                   select new
        //                                   {
        //                                       p2Id = g.Key,
        //                                       cnt = g.Count()
        //                                   }).Where(x => x.cnt > Int32.Parse(txtCount.Text)).OrderByDescending(x => x.cnt).ToList();

        //                foreach (var fly in FlyToGether)
        //                {
        //                    DataRow row = dt.NewRow();
        //                    row[0] = passenger.pid;
        //                    row[1] = fly.p2Id;
        //                    row[2] = fly.cnt;

        //                    dt.Rows.Add(row);
        //                }
        //                count++;
        //            }

        //            dataGridView.DataSource = dt;
        //            dataGridView.Refresh();

        //        }
        //        else
        //        {
        //            MessageBox.Show("Please select file for flight data.");
        //        }
        //    }
        //}


        //private void btnGreatestNumber_Click(object sender, EventArgs e)
        //{
        //    if (txtFlightFilePath.Text.Trim().Length != 0)
        //    {
        //        ProcessFile pf = new ProcessFile();
        //        List<FlightDetails> flights = pf.ReadFlightDetails(txtFlightFilePath.Text);
        //        if (flights.Count > 0)
        //        {
        //            dataGridView.DataSource = null;
        //            dataGridView.Refresh();

        //            //select PassengerId, count(flightid)
        //            //from flight_details fd
        //            //where fd.PassengerId between 1 and 100
        //            //and fd.Flight_From <> 'uk' /* between 1 and 100*/
        //            //and flight_date < (select min(flight_date) from flight_details fds
        //            //                where fds.passengerId = fd.PassengerId and flight_to = 'uk')
        //            //group by PassengerId
        //            //Order by PassengerId


        //            //var flightsPerMonth = (from f in flights
        //            //                       where f.FlightFrom.ToLower() != "uk"
        //            //                      group f by f.PassengerId
        //            //                      into g
        //            //                      select new
        //            //                      {
        //            //                          mth = g.Key,
        //            //                          cnt = g.Count()
        //            //                      }).ToList();

        //            //var distinctPassengers = flights.Where(x => x.FlightTo.ToLower() == "uk").Select(x => x.PassengerId).Distinct().Take(100);

        //            var distinctPassengers = (from f in flights
        //                                      where f.FlightTo.ToLower() == "uk"
        //                                      select new
        //                                      {
        //                                          f.PassengerId
        //                                      }).Distinct().OrderBy(x => x.PassengerId).Take(100);

        //            DataTable dt = new DataTable();
        //            dt.Columns.Add(new DataColumn("Passenger ID", typeof(Int32)));
        //            dt.Columns.Add(new DataColumn("Longest Run", typeof(Int32)));

        //            foreach (var p in distinctPassengers)
        //            {
        //                var LongestRun = (from fd in flights
        //                                  where fd.PassengerId == p.PassengerId && fd.FlightFrom.ToLower() != "uk" && fd.FlightDate < (from fds in flights where fds.FlightTo.ToLower() == "uk" && fds.PassengerId == fd.PassengerId select fds.FlightDate).Min()
        //                                  group fd by fd.PassengerId
        //                                  into g
        //                                  select new
        //                                  {
        //                                      pID = g.Key,
        //                                      cnt = g.Count(),
        //                                  }).OrderByDescending(x => x.cnt).ToList();

        //                foreach (var psg in LongestRun)
        //                {
        //                    DataRow row = dt.NewRow();
        //                    row[0] = psg.pID;
        //                    row[1] = psg.cnt;
        //                    dt.Rows.Add(row);
        //                }
        //            }

        //            dataGridView.DataSource = dt;
        //            dataGridView.Refresh();
        //        }
        //    }
        //    else
        //    {
        //        MessageBox.Show("Please provide path to a file for Flight data.");
        //    }

        //}
    }
}
