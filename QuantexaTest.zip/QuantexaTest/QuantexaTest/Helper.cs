﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace QuantexaTest
{
    public static class Helper
    {
        public static bool ValidateFileExtension(string filePath)
        {
            string fileExtension = Path.GetExtension(filePath);
            if (fileExtension.ToLower().Trim() != ".csv")
                return false;
            else
                return true;
        }
    }

    public class Test
    {
        public Int32 Passenger1Id { get; set; }
        public Int32 Passenger2Id { get; set; }
        public Int32 TogetherCount { get; set; }

        public Test()
        { }
    }
}
