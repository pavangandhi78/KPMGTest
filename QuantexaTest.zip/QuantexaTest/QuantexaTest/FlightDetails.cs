﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuantexaTest
{
    public class FlightDetails
    {
        public int PassengerId { get; set; }
        public int FlightId { get; set; }
        public string FlightFrom { get; set; }
        public string FlightTo { get; set; }
        public DateTime FlightDate { get; set; }

        public FlightDetails()
        { }

    }
}
